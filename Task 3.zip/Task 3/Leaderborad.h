#pragma once
#include <iostream>
#include <string>
using namespace std;

template <class T>
class Leaderboard
{
private:
    string names[100];
    T scores[100];
    int n;

public:
    Leaderboard()
    {
        n = 0;
    }

    void addPlayer(string pname, T pscore)
    {
        if (n < 100)
        {
            names[n] = pname;
            scores[n] = pscore;
            n++;
        }
        else
        {
            cout << "Leaderboard is full!" << endl;
        }
    }

    string getWinner()
    {
        if (n == 0)
        {
            return "No players added.";
        }
        T maxScore = scores[0];
        string winner = names[0];

        for (int i = 1; i < n; i++)
        {
            if (scores[i] > maxScore)
            {
                maxScore = scores[i];
                winner = names[i];
            }
        }
        return winner;
    }

    void display()
    {
        for (int i = 0; i < n; i++)
        {
            cout << "Name: " << names[i] << " Score: " << scores[i] << endl;
        }
    }
};

