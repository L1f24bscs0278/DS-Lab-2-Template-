#include"Leaderborad.h"
int main()
{
    Leaderboard<int> gameBoard;
    gameBoard.addPlayer("Alice", 1500);
    gameBoard.addPlayer("Bob", 2300);
    gameBoard.addPlayer("Charlie", 1900);
    gameBoard.display();
    cout << "GameBorad Leaderboard" << endl;
    cout << "Winner: " << gameBoard.getWinner() << endl;
    cout << "--------------------------------------------"<<endl;
    Leaderboard<double> gpaBoard;
    gpaBoard.addPlayer("Hamza", 3.5);
    gpaBoard.addPlayer("Ali", 3.9);
    gpaBoard.addPlayer("Daud", 3.7);
    cout << "GPA Leaderboard" << endl;
    gpaBoard.display();
    cout << "Winner: " << gpaBoard.getWinner() << endl;

    system("pause");
    return 0;
}